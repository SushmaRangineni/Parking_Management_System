package com.tcs.parkingSlot.service.srvcImpl;

import com.tcs.parkingSlot.DTO.ParkingSlotDto;
import com.tcs.parkingSlot.entity.ParkingSlot;
import com.tcs.parkingSlot.exception.SlotNotAvailableException;
import com.tcs.parkingSlot.repository.ParkingSlotRepo;
import com.tcs.parkingSlot.service.ParkingSlotSrvc;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ParkingSlotSrvcImpl implements ParkingSlotSrvc {
    @Autowired
    private ParkingSlotRepo parkingSlotRepo;

    @Override
    public List<ParkingSlotDto> getParkingSlotDtls() {
        return parkingSlotRepo.findByIsAvailableTrue().stream().map(this::convertDTO).collect(Collectors.toList());
    }

    @Override
    public ParkingSlotDto bookParkingSlot(Long slotId, Long userId) {
        ParkingSlot slot = parkingSlotRepo.findById(slotId)
                .orElseThrow(() -> new SlotNotAvailableException("Slot not found"));
        if (!slot.isAvailable()) throw new SlotNotAvailableException("Slot is already booked");

        slot.setAvailable(false);
        slot.setBookedByUser(userId);
        slot.setBookingTime(LocalDateTime.now());

        return convertDTO(parkingSlotRepo.save(slot));
    }


    @Override
    public ParkingSlotDto releaseSlot(Long slotId) {
        ParkingSlot slot = parkingSlotRepo.findById(slotId)
                .orElseThrow(() -> new SlotNotAvailableException("Slot not found"));
        slot.setAvailable(true);
        slot.setBookedByUser(null);
        slot.setBookingTime(null);
        return convertDTO(parkingSlotRepo.save(slot));
    }

    @Override
    public List<ParkingSlotDto> getUserHistoryById(Long userId) {
        return parkingSlotRepo.findByBookedByUser(userId).stream().map(this::convertDTO).collect(Collectors.toList());
    }

    private ParkingSlotDto convertDTO(ParkingSlot slot) {
        ParkingSlotDto dto = new ParkingSlotDto();
        BeanUtils.copyProperties(slot, dto);
        return dto;
    }
}

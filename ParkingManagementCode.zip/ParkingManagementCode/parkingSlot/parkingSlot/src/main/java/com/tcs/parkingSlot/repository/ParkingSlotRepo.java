package com.tcs.parkingSlot.repository;

import com.tcs.parkingSlot.entity.ParkingSlot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ParkingSlotRepo extends JpaRepository<ParkingSlot,Long> {

    List<ParkingSlot> findByIsAvailableTrue();
    List<ParkingSlot> findByBookedByUser(Long userId);

}

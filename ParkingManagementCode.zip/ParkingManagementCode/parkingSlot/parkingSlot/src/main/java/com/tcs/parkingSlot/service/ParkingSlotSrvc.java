package com.tcs.parkingSlot.service;


import com.tcs.parkingSlot.DTO.ParkingSlotDto;
import jakarta.validation.Valid;

import java.util.List;

public interface ParkingSlotSrvc {

    ParkingSlotDto bookParkingSlot(@Valid Long slotId, Long userId);

    List<ParkingSlotDto> getParkingSlotDtls();

    ParkingSlotDto releaseSlot(Long slotId);

    List<ParkingSlotDto> getUserHistoryById(Long userId);
}

package com.tcs.parkingSlot.controller;

import com.tcs.parkingSlot.DTO.ParkingSlotDto;
import com.tcs.parkingSlot.entity.ParkingSlot;
import com.tcs.parkingSlot.service.ParkingSlotSrvc;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
public class ParkingSlotCntrl {

    @Autowired
    private ParkingSlotSrvc parkingSlotSrvc;

    @PostMapping("/book/{slotId}/{userId}")
    public ParkingSlotDto bookParkingSlot(@PathVariable Long slotId, @PathVariable Long userId){
        return parkingSlotSrvc.bookParkingSlot(slotId, userId);
    }

    @GetMapping("/available")
    public List<ParkingSlotDto> getParkingSlotDtls(){
        return parkingSlotSrvc.getParkingSlotDtls();
    }

    @PostMapping("/release/{slotId}")
    public ParkingSlotDto releaseSlot(@PathVariable Long slotId) {
        return parkingSlotSrvc.releaseSlot(slotId);
    }

    @GetMapping("/history/{userId}")
    public List<ParkingSlotDto> getUserHistoryById(@PathVariable Long userId) {
        return parkingSlotSrvc.getUserHistoryById(userId);
    }
}

package com.tcs.parkingSlot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingSlotApplicationTests {

	@Test
	void contextLoads() {
	}

}

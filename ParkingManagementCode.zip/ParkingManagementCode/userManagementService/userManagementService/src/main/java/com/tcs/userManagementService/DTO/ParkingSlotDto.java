package com.tcs.userManagementService.DTO;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
public class ParkingSlotDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long slotId;

    @NotBlank(message = "Location is required")
    @Size(max = 100, message = "Location must not exceed 100 characters")
    private String location;

    @Column(unique = true, nullable = false)
    @Pattern(regexp = "^[A-Z][0-9]{2}$", message = "Slot number must be in format like A12 or B04")
    @NotBlank(message = "Slot number is required")
    @Size(max = 10, message = "Slot number must not exceed 10 characters")
    private String slotNumber;

    @NotNull(message = "Availability status must be true or false")
    private boolean isAvailable;

    private Long bookedByUser;

    private LocalDateTime bookingTime;
}

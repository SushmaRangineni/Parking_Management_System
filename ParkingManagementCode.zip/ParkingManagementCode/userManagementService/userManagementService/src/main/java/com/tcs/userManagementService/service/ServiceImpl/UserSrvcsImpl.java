package com.tcs.userManagementService.service.ServiceImpl;

import com.tcs.userManagementService.DTO.UserDTO;
import com.tcs.userManagementService.entity.User;
import com.tcs.userManagementService.exception.UserNotFoundException;
import com.tcs.userManagementService.repository.UserRepo;
import com.tcs.userManagementService.service.UserSrvcs;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserSrvcsImpl implements UserSrvcs {

    @Autowired
    private UserRepo userRepo;

    @Override
    public UserDTO createUser(@Valid UserDTO userDto) {

        User user = new User();
        BeanUtils.copyProperties(userDto, user);
        user = userRepo.save(user);
        userDto.setUserId(user.getUserId());
        return userDto;
        //return userRepo.save(userDto);
    }

    @Override
    public List<UserDTO> getUsersDtls() {

        return userRepo.findAll().stream().map(user -> {
            UserDTO dto = new UserDTO();
            BeanUtils.copyProperties(user, dto);
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public UserDTO getUsersDtlsByUserId(Long userId) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User with ID " + userId + " not found"));
        UserDTO dto = new UserDTO();
        BeanUtils.copyProperties(user, dto);
        return dto;
    }

}

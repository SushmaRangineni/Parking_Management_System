package com.tcs.userManagementService.controller;

import com.tcs.userManagementService.DTO.ParkingSlotDto;
import com.tcs.userManagementService.DTO.UserDTO;
import com.tcs.userManagementService.client.ParkingServiceClient;
import com.tcs.userManagementService.entity.User;
import com.tcs.userManagementService.service.UserSrvcs;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {


    @Autowired
    private UserSrvcs userSrvcs;

    @Autowired
    private ParkingServiceClient parkingServiceClient;

    @PostMapping("/register")
    public UserDTO createUser(@Valid @RequestBody UserDTO userDTO){

        return userSrvcs.createUser(userDTO);
    }

    @GetMapping("/")
    public List<UserDTO> getUsersDtls(){

        return userSrvcs.getUsersDtls();
    }

    @GetMapping("/{userId}")
    public UserDTO getUsersDtlsByUserId(@PathVariable Long userId){
        return userSrvcs.getUsersDtlsByUserId(userId);
    }

    @GetMapping("/{userId}/parking-history")
    public List<ParkingSlotDto> getParkingHistory(@PathVariable Long userId) {
        return parkingServiceClient.getUserHistory(userId);
    }

    @PostMapping("/{userId}/book/{slotId}")
    public ParkingSlotDto bookSlot(@PathVariable Long userId, @PathVariable Long slotId) {
        return parkingServiceClient.bookSlot(slotId, userId);
    }

    @PostMapping("/release/{slotId}")
    public ParkingSlotDto releaseSlot(@PathVariable Long slotId) {
        return parkingServiceClient.releaseSlot(slotId);
    }
}


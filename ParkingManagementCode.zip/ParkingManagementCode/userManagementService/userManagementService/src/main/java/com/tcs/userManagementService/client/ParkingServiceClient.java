package com.tcs.userManagementService.client;

import com.tcs.userManagementService.DTO.ParkingSlotDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;


@FeignClient(name = "PARKINGSLOT")
public interface ParkingServiceClient {

    @GetMapping("/api/parking/history/{userId}")
    List<ParkingSlotDto> getUserHistory(@PathVariable("userId") Long userId);

    @PostMapping("/api/parking/book/{slotId}/{userId}")
    ParkingSlotDto bookSlot(@PathVariable Long slotId, @PathVariable Long userId);

    @PostMapping("/api/parking/release/{slotId}")
    ParkingSlotDto releaseSlot(@PathVariable Long slotId);
}

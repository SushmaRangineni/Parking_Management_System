package com.tcs.userManagementService.service;


import com.tcs.userManagementService.DTO.UserDTO;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

public interface UserSrvcs {
    UserDTO createUser(@Valid UserDTO userDTO);

    List<UserDTO> getUsersDtls();

    UserDTO getUsersDtlsByUserId(Long userId);
}
